-- phpMyAdmin SQL Dump
-- version 3.3.2deb1
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Mer 29 Mai 2013 à 22:57
-- Version du serveur: 5.1.41
-- Version de PHP: 5.3.2-1ubuntu4.18

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `verboc`
--

-- --------------------------------------------------------

--
-- Structure de la table `sauzet_model`
--

CREATE TABLE IF NOT EXISTS `sauzet_model` (
  `nummodel` varchar(5) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `verb_prime` varchar(16) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `label_conjugation` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `conjugations` varchar(600) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `is_manual` tinyint(1) NOT NULL,
  `extras` varchar(32) DEFAULT NULL,
  `alias` varchar(5) DEFAULT NULL,
  `impersonal` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `sauzet_model`
--

INSERT INTO `sauzet_model` (`nummodel`, `verb_prime`, `label_conjugation`, `conjugations`, `is_manual`, `extras`, `alias`, `impersonal`) VALUES
('001', 'èsser', 'auxiliar', '00:soi,ès,es,sèm,sètz,son|01:èri,èras,èra,èrem,èretz,èran|02:foguèri,foguères,foguèt,foguèrem,foguèretz,foguèron|03:serai,seràs,serà,serem,seretz,seràn|04:èsser|05:essent|06:estat,estada|07:siá,siam,siatz,siás,siam,siatz|08:siá,siás,siá,siam,siatz,sián|09:foguèsse,foguèsses,foguèsse,foguèssem,foguèssetz,foguèsson|10:seriái,seriás,seriá,seriam,seriatz,serián', 1, NULL, NULL, 0),
('002', 'aver', 'auxiliar', '00:ai,as,a,avèm,avètz,an|01:aviái,aviás,aviá,aviam,aviatz,avián|02:aguèri,aguères,aguèt,aguèrem,aguèretz,aguèron|03:aurai,auràs,aurà,aurem,auretz,auràn|04:aver|05:avent|06:agut,aguda|07:aja,ajam,ajatz,ajas,ajam,ajatz|08:aja,ajas,aja,ajam,ajatz,ajan|09:aguèsse,aguèsses,aguèsse,aguèssem,aguèssetz,aguèsson|10:auriái,auriás,auriá,auriam,auriatz,aurián', 1, NULL, NULL, 0),
('003', 'anar', 'semiauxiliar', '00:vau,vas,va,anam,anatz,van|01:anavi,anavas,anava,anàvem,anàvetz,anavan|02:anèri,anères,anèt,anèrem,anèretz,anèron|03:anarai,anaràs,anarà,anarem,anaretz,anaràn|04:anar|05:anant|06:anat,anada|07:vai,anem,anatz,anes,anem,anetz|08:ane,anes,ane,anem,anetz,anen|09:anèsse,anèsses,anèsse,anèssem,anèssetz,anèsson|10:anariái,anariás,anariá,anariam,anariatz,anarián', 1, NULL, NULL, 0),
('004', 'far', 'semiauxiliar', '00:fau,fas,fa,fasèm,fasètz,fan|01:fasiái,fasiás,fasiá,fasiam,fasiatz,fasián|02:faguèri,faguères,faguèt,faguèrem,faguèretz,faguèron|03:farai,faràs,farà,farem,faretz,faràn|04:far~faire|05:fasent|06:fach,facha|07:fai,fagam,fasètz,fagas,fagam,fagatz|08:faga,fagas,faga,fagam,fagatz,fagan|09:faguèsse,faguèsses,faguèsse,faguèssem,faguèssetz,faguèsson|10:fariái,fariás,fariá,fariam,fariatz,farián', 1, NULL, NULL, 0),
('100', 'cantar', 'conjugason 1 non alternanta', NULL, 0, NULL, NULL, 0),
('101', 'caçar', 'conjugason 1 alternanta ç/c', NULL, 0, NULL, NULL, 0),
('102', 'lecar', 'conjugason 1 alternanta c/qu', NULL, 0, NULL, NULL, 0),
('103', 'assajar', 'conjugason 1 alternanta j/g', NULL, 0, NULL, NULL, 0),
('104', 'pegar', 'conjugason 1 alternanta g/gu', NULL, 0, NULL, NULL, 0),
('105 c', 'coar', 'conjugason 1 non alternanta iat', NULL, 0, NULL, NULL, 0),
('105 d', 'enviar', 'conjugason 1 non alternanta iat', NULL, 0, NULL, NULL, 0),
('105 e', 'tuar', 'conjugason 1 non alternanta iat', NULL, 0, NULL, NULL, 0),
('106 a', 'cambiar', 'conjugason 1 non alternanta iòd', NULL, 0, NULL, NULL, 0),
('106 b', 'vendemiar', 'conjugason 1 non alternanta iòd', NULL, 0, NULL, NULL, 0),
('106 c', 'romiar', 'conjugason 1 non alternanta iòd', NULL, 0, NULL, NULL, 0),
('106 d', 'alimpiar', 'conjugason 1 non alternanta iòd', NULL, 0, NULL, NULL, 0),
('106 e', 'estudiar', 'conjugason 1 non alternanta iòd', NULL, 0, NULL, NULL, 0),
('106 f', 'delaiar', 'conjugason 1 non alternanta iòd', NULL, 0, NULL, NULL, 0),
('107 a', 'dar', 'conjugason 1 monosillabs', NULL, 0, NULL, NULL, 0),
('110 a', 'levar', 'conjugason 1 alternanta è/e', NULL, 0, NULL, NULL, 0),
('110 b', 'abandieirar', 'conjugason 1 alternanta è/e', NULL, 0, NULL, NULL, 0),
('111', 'breçar', 'conjugason 1 alternanta è/e, ç/c', NULL, 0, NULL, NULL, 0),
('112', 'becar', 'conjugason 1 alternanta è/e, c/qu', NULL, 0, NULL, NULL, 0),
('113', 'apiejar', 'conjugason 1 alternanta è/e, j/g', NULL, 0, NULL, NULL, 0),
('114', 'negar', 'conjugason 1 alternanta è/e, g/gu', NULL, 0, NULL, NULL, 0),
('115', 'crear', 'conjugason 1 alternanta è/e, iat', NULL, 0, NULL, NULL, 0),
('116', 'especiar', 'conjugason 1 alternanta è/e, iòd', NULL, 0, NULL, NULL, 0),
('120', 'trobar', 'conjugason 1 alternanta ò/o', NULL, 0, NULL, NULL, 0),
('121', 'forçar', 'conjugason 1 alternanta ò/o, ç/c', NULL, 0, NULL, NULL, 0),
('122', 'tocar', 'conjugason 1 alternanta ò/o, c/qu', NULL, 0, NULL, NULL, 0),
('123', 'escorjar', 'conjugason 1 alternanta ò/o, j/g', NULL, 0, NULL, NULL, 0),
('124', 'jogar', 'conjugason 1 alternanta ò/o, g/gu', NULL, 0, NULL, NULL, 0),
('125', 'aboar', 'conjugason 1 alternanta ò/o iat', NULL, 0, NULL, NULL, 0),
('126 a', 'negociar', 'conjugason 1 alternanta ò/o iòd', NULL, 0, NULL, NULL, 0),
('126 b', 'joiar', 'conjugason 1 alternanta ò/o iòd', NULL, 0, NULL, NULL, 0),
('130', 'profechar', 'conjugason 1 alternanta iè/e', NULL, 0, NULL, NULL, 0),
('140', 'sonhar', 'conjugason 1 alternanta uè/o', NULL, 0, NULL, NULL, 0),
('143', 'vojar', 'conjugason 1 alternanta uè/o, j/g', NULL, 0, NULL, NULL, 0),
('150', 'soudar', 'conjugason 1 alternanta òu/ou [?w]', NULL, 0, NULL, NULL, 0),
('154', 'mougar', 'conjugason 1 alternanta òu/ou, g/gu [?w]', NULL, 0, NULL, NULL, 0),
('156', 'oufiar', 'conjugason 1 alternanta òu/ou, iòd  [?w]', NULL, 0, NULL, NULL, 0),
('160', 'recular', 'conjugason 1 alternanta uo/u', NULL, 0, NULL, NULL, 0),
('173', 'reclujar', 'conjugason 1 alternanta uè/u, j/g', NULL, 0, NULL, NULL, 0),
('170', 'estrasulhar', 'conjugason 1 alternanta uè/u', NULL, 0, NULL, NULL, 0),
('170', 'estrasulhar', 'tematic, alternant uè/u', NULL, 0, NULL, NULL, 0),
('230', 'morir', 'conjugason 2 part passat irregular', NULL, 0, NULL, NULL, 0),
('300', 'rompre', 'conjugason 3 sens alt., ocl . sorda (p)', '00:|01:|02:|03:|04:|05:|06:|07:|08:|09:|10:|', 0, NULL, NULL, 0),
('301', 'batre', 'conjugason 3 sens alt., ocl . sorda (t)', '00:|01:|02:|03:|04:|05:|06:|07:|08:|09:|10:|', 0, NULL, NULL, 0),
('302', 'fotre ', 'conjugason 3 sens alt., ocl . sorda (t)', '00:|01:|02:|03:|04:|05:|06:|07:|08:|09:|10:|', 0, NULL, NULL, 0),
('303', 'metre', 'conjugason 3 sens alt. , ocl . sorda (t) part.pas. Irr.', '00:|01:|02:|03:|04:|05:|06:.s,.sa|07:|08:|09:|10:|', 0, NULL, NULL, 0),
('304', 'ficre ', 'conjugason 3 radical en ocl . sorda ([k]), alt. ort. c / qu', '00:|01:|02:|03:|04:|05:|06:|07:|08:|09:|10:|', 0, NULL, NULL, 0),
('313', 'escodre  ', 'conjugason 3 , alt d/t', '00:i,es,.t,èm,ètz,on|01:|02:|03:|04:|05:|06:|07:.t,am,ètz,as,am,atz|08:|09:|10:|', 0, NULL, NULL, 0),
('314', 'mèdre', 'conjugason 3 alt. è / e, alt d/t', '00:i,es,.t,em,ètz,on|01:|02:|03:|04:|05:|06:|07:.t,am,ètz,as,am,atz|08:|09:|10:|', 0, NULL, NULL, 0),
('311', 'saber', 'conjugason 3 tres radicals, alt b/p', '00:i,es,.p,èm,ètz,on|01:|02:.upèri,.upères,.upèt,.upèrem,.upèretz,.upèron|03:.uprai,.upràs,.uprà,.uprem,.upretz,.upràn|04:|05:|06:.uput,.upuda|07:..àpia,.piam,.piatz,..àpias,.piam,.piatz|08:..àpia,..àpias,..àpia,.piam,.piatz,..àpian|09:.upèsse,.upèsses,.upèsse,.upèssem,.upèssetz,.upèsson|10:.upriái,.upriás,.upriá,.upriam,.upriatz,.uprián|', 0, NULL, NULL, 0),
('312', 'recebre', 'conjugason 3 dos radicals, alt b/p', '00:i,es,.p,èm,ètz,on|01:|02:|03:|04:|05:|06:|07:.p,.piam,ètz,..épias,.piam,.piatz|08:..épia,..épias,..épia,.piam,.piatz,..épian|09:|10:|', 0, NULL, NULL, 0),
('315', 'poder', 'conjugason 3 quatre radicals, alt. ò / o, alt d/t', '00:..òdi,..òdes,..òt,èm,ètz,..òdon|01:|02:.guèri,.guères,.guèt,.guèrem,.guèretz,.guèron|03:.irai,.iràs,.irà,.irem,.iretz,.iràn|04:|05:|06:.gut,.guda|07:..òsca,.scam,.scatz,..òscas,.scam,.scatz|08:..òsca,..òscas,..òsca,.scam,.scatz,..òscan|09:.guèsse,.guèsses,.guèsse,.guèssem,.guèssetz,.guèsson|10:.iriái,.iriás,.iriá,.iriam,.iriatz,.irián|', 0, '1', NULL, 0),
('321', 'ardre', 'conjugason 3 alt [d]/[t], part.pas. Irr.', '00:|01:|02:|03:|04:|05:|06:.s,.sa|07:|08:|09:|10:|', 0, NULL, NULL, 0),
('322', 'pèrdre', 'conjugason 3 alt. è / e, alt [d]/[t]', '00:|01:|02:|03:|04:|05:|06:|07:|08:|09:|10:|', 0, NULL, NULL, 0),
('323', 'mòrdre', 'conjugason 3 alt. ò / o, alt [d]/[t]', '00:|01:|02:|03:|04:|05:|06:|07:|08:|09:|10:|', 0, NULL, NULL, 0),
('324', 'vendre', 'conjugason 3 alt [nd]/[n]', '00:|01:|02:|03:|04:|05:|06:|07:|08:|09:|10:|', 0, NULL, NULL, 0),
('325', 'encendre', 'conjugason 3 alt [nd]/[n], part. pass. Irr.', '00:|01:|02:|03:|04:|05:|06:.......encés,..sa|07:|08:|09:|10:|', 0, NULL, NULL, 0),
('330', 'cóser ', 'conjugason 3 alt [z]/[s]', '00:|01:|02:|03:erai,eràs,erà,erem,eretz,eràn|04:|05:|06:|07:|08:|09:|10:eriái,eriás,eriá,eriam,eriatz,erián|', 0, NULL, NULL, 0),
('331', 'aucire', 'conjugason 3 alt [z]/[s], part. pass. Irr.', '00:si,ses,.ís,sèm,sètz,son|01:siái,siás,siá,siam,siatz,sián|02:guèri,guères,guèt,guèrem,guèretz,guèron|03:|04:|05:sent|06:.ís,sa|07:.ís,gam,sètz,gas,gam,gatz|08:ga,gas,ga,gam,gatz,gan|09:guèsse,guèsses,guèsse,guèssem,guèssetz,guèsson|10:|', 0, NULL, NULL, 0),
('332', 'sufire', 'conjugason 3 alt [z]/[s], part. pass. Irr.', '00:si,ses,.ís,sèm,sètz,son|01:siái,siás,siá,siam,siatz,sián|02:guèri,guères,guèt,guèrem,guèretz,guèron|03:|04:|05:sent|06:t,da|07:.ís,gam,sètz,gas,gam,gatz|08:ga,gas,ga,gam,gatz,gan|09:guèsse,guèsses,guèsse,guèssem,guèssetz,guèsson|10:|', 0, NULL, NULL, 0),
('333', 'rire', 'conjugason 3 alt -s- [z]/-tz [?]', '00:si,ses,tz,sèm,sètz,son|01:siái,siás,siá,siam,siatz,sián|02:guèri,guères,guèt,guèrem,guèretz,guèron|03:|04:|05:sent|06:gut,guda|07:tz,gam,sètz,gas,gam,gatz|08:ga,gas,ga,gam,gatz,gan|09:guèsse,guèsses,guèsse,guèssem,guèssetz,guèsson|10:|', 0, NULL, NULL, 0),
('334', 'dire', 'conjugason 3 alt -s- [z]/-tz [?]', '00:si,ses,tz,sèm,sètz,son|01:siái,siás,siá,siam,siatz,sián|02:guèri,guères,guèt,guèrem,guèretz,.guèron|03:|04:|05:sent|06:ch,cha|07:ga,gam,gatz,gas,gam,gatz|08:ga,gas,ga,gam,gatz,gan|09:guèsse,guèsses,guèsse,guèssem,guèssetz,guèsson|10:|', 0, NULL, NULL, 0),
('335', 'aduire', 'conjugason 3 alt -s- [z]/-tz [?]', '00:.si,.ses,.tz,.sèm,.sètz,.son|01:.siái,.siás,.siá,.siam,.siatz,.sián|02:.guèri,.guères,.guèt,.guèrem,.guèretz,.guèron|03:|04:|05:.sent|06:.ch,.cha|07:.tz,.gam,.sètz,.gas,.gam,.gatz|08:.ga,.gas,.ga,.gam,.gatz,.gan|09:.guèsse,.guèsses,.guèsse,.guèssem,.guèssetz,.guèsson|10:', 0, NULL, NULL, 0),
('336', 'conclure', 'conjugason 3 alt -s- [z]/-tz [?]', '00:si,ses,tz,sèm,sètz,son|01:siái,siás,siá,siam,siatz,sián|02:guèri,guères,guèt,guèrem,guèretz,guèron|03:|04:|05:sent|06:.ús,sa|07:tz,gam,gatz,gas,gam,gatz|08:ga,gas,ga,gam,gatz,gan|09:guèsse,guèsses,guèsse,guèssem,guèssetz,guèsson|10:|', 0, NULL, NULL, 0),
('337', 'fúger', 'atematic, rad. en -g, alt. [-?-]/[-?], p. p. irreg.', '00:...ugi,...uges,...ug,...ugèm,...ugètz,...ujon|01:...ugiái,...ugiás,...ugiá,...ugiam,...ugiatz,...ugián|02:...ugèri,...ugères,...ugèt,...ugèrem,...ugèretz,...ugèron|03:...ugerai,...ugeràs,...ugerà,...ugerem,...ugeretz,...ugeràn|04:|05:...ugent|06:...ugit,...ugida|07:...ug,...ujam,...ugètz,...ujas,...ujam,...ujatz|08:...uja,...ujas,...uja,...ujam,...ujatz,...ujan|09:...ugèsse,...ugèsses,...ugèsse,...ugèssem,...ugèssetz,...ugèsson|10:...ugeriái,...ugeriás,...ugeriá,...ugeriam,...ugeriatz,...ugerián|', 0, NULL, NULL, 0),
('338', 'plànger', 'conjugason 3 alt. -ng- [n?], -ng [n?]', '00:....angi,....anges,....ang,....angèm,....angètz,....angon|01:....angiái,....angiás,....angiá,....angiam,....angiatz,....angián|02:....anguèri,....anguères,....anguèt,....anguèrem,....anguèretz,....anguèron|03:....angerai,....angeràs,....angerà,....angerem,....angeretz,....angeràn|04:|05:....angent|06:....angut,....anguda|07:,.gam,ètz,.gas,.gam,.gatz|08:.ga,.gas,.ga,.gam,.gatz,.gan|09:.guèsse,.guèsses,.guèsse,.guèssem,.guèssetz,.guèsson|10:eriái,eriás,eriá,eriam,eriatz,erián|', 0, NULL, NULL, 0),
('340', 'taire', 'conjugason 3 alt -s- [z]/-i [j]', '00:.si,.ses,,.sèm,.sètz,.son|01:.siái,.siás,.siá,.siam,.siatz,.sián|02:.sèri,.sères,.sèt,.sèrem,.sèretz,.sèron|03:|04:|05:.sent|06:.sut,.suda|07:,.sam,.sètz,.sas,.sam,.satz|08:.sa,.sas,.sa,.sam,.satz,.san|09:.sèsse,.sèsses,.sèsse,.sèssem,.sèssetz,.sèsson|10:|', 0, NULL, NULL, 0),
('341', 'creire ', 'conjugason 3, alt -s- [z]/-i [j]', '00:.si,.ses,,.sèm,.sètz,.son|01:.siái,.siás,.siá,.siam,.siatz,.sián|02:.guèri,.guères,.guèt,.guèrem,.guèretz,.guèron|03:|04:|05:.sent|06:.gut,.guda|07:,.gam,.sètz,.gas,.gam,.gatz|08:.ga,.gas,.ga,.gam,.gatz,.gan|09:.guèsse,.guèsses,.guèsse,.guèssem,.guèssetz,.guèsson|10:', 0, NULL, NULL, 0),
('342', 'traire', 'conjugason 3, alt -s- [z]/-i [j], part. pass. Irr.', '00:.si,.ses,,.sèm,.sètz,.son|01:.siái,.siás,.siá,.siam,.siatz,.sián|02:.guèri,.guères,.guèt,.guèrem,.guèretz,.guèron|03:|04:|05:.sent|06:.ch,.cha|07:,.gam,.sètz,.gas,.gam,.gatz|08:.ga,.gas,.ga,.gam,.gatz,.gan|09:.guèsse,.guèsses,.guèsse,.guèssem,.guèssetz,.guèsson|10:|', 0, NULL, NULL, 0),
('343', 'sèire', 'conjugason 3, alt. è / e, alt -s- [z]/-i [j], part. pass. Irr.', '00:.si,.ses,,.sèm,.sètz,.son|01:.siái,.siás,.siá,.siam,.siatz,.sián|02:.guèri,.guères,.guèt,.guèrem,.guèretz,.guèron|03:|04:|05:.sent|06:.gut,.guda|07:,.gam,.sètz,.gas,.gam,.gatz|08:.ga,.gas,.ga,.gam,.gatz,.gan|09:.guèsse,.guèsses,.guèsse,.guèssem,.guèssetz,.guèsson|10:', 0, NULL, NULL, 0),
('344', 'fòire', 'conjugason 3, alt. ò / o, alt -s- [z]/-i [j]', '00:.si,.ses,,.sèm,.sètz,.son|01:.siái,.siás,.siá,.siam,.siatz,.sián|02:.sèri,.sères,.sèt,.sèrem,.sèretz,.sèron|03:|04:|05:.sent|06:.gut,.guda|07:,.gam,.sètz,.gas,.gam,.gatz|08:.ga,.gas,.ga,.gam,.gatz,.gan|09:.gèsse,.gèsses,.gèsse,.gèssem,.gèssetz,.gèsson|10:|', 0, NULL, NULL, 0),
('345', 'còire', 'conjugason 3, alt. ò / o, alt -s- [z]/-i [j], part. pass. Irr.', '00:.si,.ses,,.sèm,.sètz,.son|01:.siái,.siás,.siá,.siam,.siatz,.sián|02:.guèri,.guères,.guèt,.guèrem,.guèretz,.guèron|03:|04:|05:.sent|06:...uèch,...uècha|07:,.gam,.sètz,.gas,.gam,.gatz|08:.ga,.gas,.ga,.gam,.gatz,.gan|09:.guèsse,.guèsses,.guèsse,.guèssem,.guèssetz,.guèsson|10:', 0, NULL, NULL, 0),
('346', 'veire', 'conjugason 3, alt -s- [z]/-i [j], part. pass. Irr.', '00:.si,.ses,,.sèm,.sètz,.son|01:.siái,.siás,.siá,.siam,.siatz,.sián|02:.gèri,.gères,.gèt,.gèrem,.gèretz,.gèron|03:|04:|05:.sent|06:..ist,..ista|07:.ja,.jam,.jatz,.jas,.jam,.jatz|08:.ja,.jas,.ja,.jam,.jatz,.jan|09:.gèsse,.gèsses,.gèsse,.gèssem,.gèssetz,.gèsson|10:|', 0, NULL, NULL, 0),
('350', 'pàisser', 'conjugason 3, dos rad., -ais(s)-,  -asc-', '00:i,es,.,èm,ètz,on|01:|02:...squèri,...squères,...squèt,...squèrem,...squèretz,...squèron|03:erai,eràs,erà,erem,eretz,eràn|04:|05:|06:...scut,...scuda|07:.,...scam,ètz,...scas,...scam,...scatz|08:...sca,...scas,...sca,...scam,...scatz,...scan|09:...squèsse,...squèsses,...squèsse,...squèssem,...squèssetz,...squèsson|10:eriái,eriás,eriá,eriam,eriatz,erián|', 0, NULL, NULL, 0),
('351', 'nàisser', 'conjugason 3, dos rad., -ais(s)-,  -asc-, (part. pass. Irr.)', '00:i,es,.,èm,ètz,on|01:|02:...squèri,...squères,...squèt,...squèrem,...squèretz,...squèron|03:erai,eràs,erà,erem,eretz,eràn|04:|05:|06:...scut,...scuda|07:.,...scam,ètz,...scas,...scam,...scatz|08:...sca,...scas,...sca,...scam,...scatz,...scan|09:...squèsse,...squèsses,...squèsse,...squèssem,...squèssetz,...squèsson|10:eriái,eriás,eriá,eriam,eriatz,erián|', 0, NULL, NULL, 0),
('352', 'créisser', 'conjugason 3, dos rad., -eis(s)-,  -esc', '00:i,es,.,èm,ètz,on|01:|02:...squèri,...squères,...squèt,...squèrem,...squèretz,...squèron|03:erai,eràs,erà,erem,eretz,eràn|04:|05:|06:...scut,...scuda|07:.,...scam,ètz,...scas,...scam,...scatz|08:...sca,...scas,...sca,...scam,...scatz,...scan|09:...squèsse,...squèsses,...squèsse,...squèssem,...squèssetz,...squèsson|10:eriái,eriás,eriá,eriam,eriatz,erián|', 0, NULL, NULL, 0),
('353', 'conéisser', 'conjugason 3, tres rad., -eis(s)-,  -esc-, -egu', '00:i,es,.,èm,ètz,on|01:|02:...guèri,...guères,...guèt,...guèrem,...guèretz,...guèron|03:erai,eràs,erà,erem,eretz,eràn|04:|05:.sent|06:...scut,...scuda|07:.,...scam,...scètz,...scas,...scam,...scatz|08:...sca,...scas,...sca,...scam,...scatz,...scan|09:...guèsse,...guèsses,...guèsse,...guèssem,...guèssetz,...guèsson|10:eriái,eriás,eriá,eriam,eriatz,erián|', 0, NULL, NULL, 0),
('354', 'ròisser', 'conjugason 3, tres rad. ?, alt ò / o, -òis(s)-,  -òsc-, -ogu-,', '00:i,es,.,èm,ètz,on|01:|02:...squèri,...squères,...squèt,...squèrem,...squèretz,...squèron|03:erai,eràs,erà,erem,eretz,eràn|04:|05:|06:...scut,...scuda|07:.,...scam,ètz,...scas,...scam,...scatz|08:...sca,...scas,...sca,...scam,...scatz,...scan|09:...squèsse,...squèsses,...squèsse,...squèssem,...squèssetz,...squèsson|10:eriái,eriás,eriá,eriam,eriatz,erián|', 0, NULL, NULL, 0),
('355', 'mólzer', 'conjugason 3, alt -lz- [(l)z]/-lz [(l)s]', '00:i,es,.s,èm,ètz,on|01:|02:|03:erai,eràs,erà,erem,eretz,eràn|04:|05:|06:|07:.s,am,ètz,as,am,atz|08:|09:|10:eriái,eriás,eriá,eriam,eriatz,erián|', 0, NULL, NULL, 0),
('356', 'vòuser', 'conjugason 3, alt ou [?w] / òu [?w] (solament grafica), alt -s- ', '00:i,es,.s,èm,ètz,on|01:|02:|03:erai,eràs,erà,erem,eretz,eràn|04:|05:|06:|07:.s,am,ètz,as,am,atz|08:|09:|10:eriái,eriás,eriá,eriam,eriatz,erián|', 0, NULL, NULL, 0),
('357', 'claure', 'conjugason 3, dos rad., ind. pres. 3 irr., part. pass. Irr.', '00:si,ses,,sèm,sètz,son|01:siái,siás,siá,siam,siatz,sián|02:guèri,guères,guèt,guèrem,guèretz,guèron|03:|04:|05:sent|06:s,sa|07:,gam,sètz,gas,gam,gatz|08:ga,gas,ga,gam,gatz,gan|09:guèsse,guèsses,guèsse,guèssem,guèssetz,guèsson|10:|', 0, NULL, NULL, 0),
('358', 'tòrcer', 'conjugason 3, alt ò / o, alt. -c-, -ç-, part. pass. Irr.', '00:.ci,.ces,.ç,.cèm,.cètz,.çon|01:.ciái,.ciás,.ciá,.ciam,.ciatz,.cián|02:.cèri,.cères,.cèt,.cèrem,.cèretz,.cèron|03:.cerai,.ceràs,.cerà,.cerem,.ceretz,.ceràn|04:|05:.cent|06:.çut,.çuda|07:.ç,.çam,.cètz,.ças,.çam,.çatz|08:.ça,.ças,.ça,.çam,.çatz,.çan|09:.cèsse,.cèsses,.cèsse,.cèssem,.cèssetz,.cèsson|10:.ceriái,.ceriás,.ceriá,.ceriam,.ceriatz,.cerián|', 0, NULL, NULL, 0),
('359', 'véncer', 'conjugason 3, dos rad. venc- [bens-], venc- [be?k-], alt. -c-, -', '00:.ci,.ces,.ç,.cèm,.cètz,.çon|01:.ciái,.ciás,.ciá,.ciam,.ciatz,.cián|02:|03:.cerai,.ceràs,.cerà,.cerem,.ceretz,.ceràn|04:|05:.cent|06:|07:.ç,.cam,.cètz,.cas,.cam,.catz|08:|09:|10:.ceriái,.ceriás,.ceriá,.ceriam,.ceriatz,.cerián|', 0, NULL, NULL, 0),
('360', 'beure', 'conjugason 3, , alt -v- [?]/-u [w]', '00:.vi,.ves,,.vèm,.vètz,.von|01:.viái,.viás,.viá,.viam,.viatz,.vián|02:.guèri,.guères,.guèt,.guèrem,.guèretz,.guèron|03:|04:|05:.vent|06:.gut,.guda|07:,.gam,.vètz,.gas,.gam,.gatz|08:.ga,.gas,.ga,.gam,.gatz,.gan|09:.guèsse,.guèsses,.guèsse,.guèssem,.guèssetz,.guèsson|10:|', 0, NULL, NULL, 0),
('361', 'dever', 'conjugason 3, , alt -v- [?]/-u [w], inf. en -er tonic', '00:.vi,.ves,.u,.vèm,.vètz,.von|01:.viái,.viás,.viá,.viam,.viatz,.vián|02:.guèri,.guères,.guèt,.guèrem,.guèretz,.guèron|03:.urai,.uràs,.urà,.urem,.uretz,.uràn|04:|05:.vent|06:.gut,.guda|07:.u,.gam,.vètz,.gas,.gam,.gatz|08:.ga,.gas,.ga,.gam,.gatz,.gan|09:.guèsse,.guèsses,.guèsse,.guèssem,.guèssetz,.guèsson|10:.uriái,.uriás,.uriá,.uriam,.uriatz,.urián|', 0, NULL, NULL, 0),
('362', 'viure', 'conjugason 3, , alt -v- [?]/-u [w]', '00:.vi,.ves,.u,.vèm,.vètz,.von|01:.viái,.viás,.viá,.viam,.viatz,.vián|02:.squèri,.squères,.squèt,.squèrem,.squèretz,.squèron|03:|04:|05:.vent|06:.scut,.scuda|07:.u,.scam,.vètz,.scas,.scam,.scatz|08:.sca,.scas,.sca,.scam,.scatz,.scan|09:.squèsse,.squèsses,.squèsse,.squèssem,.squèssetz,.squèsson|10:|', 0, NULL, NULL, 0),
('363', 'escriure', 'conjugason 3, , alt -v- [?]/-u [w]', '00:.vi,.ves,,.vèm,.vètz,.von|01:.viái,.viás,.viá,.viam,.viatz,.vián|02:.guèri,.guères,.guèt,.guèrem,.guèretz,.guèron|03:|04:|05:.vent|06:.ch,.cha|07:,.gam,.vètz,.gas,.gam,.gatz|08:.ga,.gas,.ga,.gam,.gatz,.gan|09:.guèsse,.guèsses,.guèsse,.guèssem,.guèssetz,.guèsson|10:|', 0, NULL, NULL, 0),
('364', 'mòure', 'conjugason 3, alt ò / o (et òu / ou), alt -v- [?]/-u [w]', '00:.vi,.ves,,.vèm,.vètz,.von|01:.viái,.viás,.viá,.viam,.viatz,.vián|02:.guèri,.guères,.guèt,.guèrem,.guèretz,.guèron|03:|04:|05:.vent|06:.gut,.guda|07:,.gam,.vètz,.gas,.gam,.gatz|08:.ga,.gas,.ga,.gam,.gatz,.gan|09:.guèsse,.guèsses,.guèsse,.guèssem,.guèssetz,.guèsson|10:|', 0, NULL, NULL, 0),
('365', 'sòlver', 'conjugason 3, alt ò / o, alt -lv- [l?]/-lv [l]', '00:|01:|02:.guèri,.guères,.guèt,.guèrem,.guèretz,.guèron|03:erai,eràs,erà,erem,eretz,eràn|04:|05:|06:.gut,.guda|07:,.gam,ètz,.gas,.gam,.gatz|08:.ga,.gas,.ga,.gam,.gatz,.gan|09:.guèsse,.guèsses,.guèsse,.guèssem,.guèssetz,.guèsson|10:eriái,eriás,eriá,eriam,eriatz,erián|', 0, NULL, NULL, 0),
('370', 'témer', 'conjugason 3, radical en -m, alt. [-n], [-m-]', '00:|01:|02:|03:erai,eràs,erà,erem,eretz,eràn|04:|05:|06:|07:|08:|09:|10:eriái,eriás,eriá,eriam,eriatz,rián|', 0, NULL, NULL, 0),
('371', 'téner', 'conjugason 3, dos rad. ten-, teng-, inf. -er atòn', '00:|01:|02:guèri,guères,guèt,guèrem,guèretz,guèron|03:drai,dràs,drà,drem,dretz,dràn|04:|05:|06:gut,guda|07:,gam,ètz,gas,gam,gatz|08:ga,gas,ga,gam,gatz,gan|09:guèsse,guèsses,guèsse,guèssem,guèssetz,guèsson|10:driái,driás,driá,driam,driatz,drián|', 0, NULL, NULL, 0),
('372', 'venir', 'conjugason 3, dos rad. ven-, veng-, , inf. Irr.', '00:|01:|02:guèri,guères,guèt,guèrem,guèretz,guèron|03:drai,dràs,drà,drem,dretz,dràn|04:|05:|06:gut,guda|07:..èni,gam,ètz,gas,gam,gatz|08:ga,gas,ga,gam,gatz,gan|09:guèsse,guèsses,guèsse,guèssem,guèssetz,guèsson|10:driái,driás,driá,driam,driatz,drián|', 0, NULL, NULL, 0),
('373', 'prene', 'conjugason 3, dos rad. pren-, preng-, inf. e part. pas. Irr.', '00:ni,nes,n,nèm,nètz,non|01:niái,niás,niá,niam,niatz,nián|02:nguèri,nguères,nguèt,nguèrem,nguèretz,nguèron|03:ndrai,ndràs,ndrà,ndrem,ndretz,ndràn|04:|05:nent|06:s,sa|07:n,ngam,nètz,ngas,ngam,ngatz|08:nga,ngas,nga,ngam,ngatz,ngan|09:nguèsse,nguèsses,nguèsse,nguèssem,nguèssetz,nguèsson|10:ndriái,ndriás,ndriá,ndriam,ndriatz,ndrián|', 0, NULL, NULL, 0),
('374', 'cèrner', 'conjugason 3, alt. è / e, alt -rn- [rn]/-rn [r]', '00:|01:|02:|03:erai,eràs,erà,erem,eretz,eràn|04:|05:|06:|07:|08:|09:|10:eriái,eriás,eriá,eriam,eriatz,erián|', 0, NULL, NULL, 0),
('380', 'tànher', 'conjugason 3, dos rad. -nh- , -ng-', '00:|01:|02:.guèri,.guères,.guèt,.guèrem,.guèretz,.guèron|03:erai,eràs,erà,erem,eretz,eràn|04:|05:|06:.gut,.guda|07:,.gam,ètz,.gas,.gam,.gatz|08:.ga,.gas,.ga,.gam,.gatz,.gan|09:.guèsse,.guèsses,.guèsse,.guèssem,.guèssetz,.guèsson|10:eriái,eriás,eriá,eriam,eriatz,erián|', 0, NULL, NULL, 0),
('381', 'plànher', 'conjugason 3, dos rad. -anh- , -ang-, part. pass. Irreg.', '00:|01:|02:.guèri,.guères,.guèt,.guèrem,.guèretz,.guèron|03:erai,eràs,erà,erem,eretz,eràn|04:|05:|06:.gut,.guda|07:,.gam,ètz,.gas,.gam,.gatz|08:.ga,.gas,.ga,.gam,.gatz,.gan|09:.guèsse,.guèsses,.guèsse,.guèssem,.guèssetz,.guèsson|10:eriái,eriás,eriá,eriam,eriatz,erián|', 1, NULL, NULL, 0),
('382', 'cénher', 'conjugason 3, dos rad. -enh- , -eng-, part. pass. Irreg.', '00:|01:|02:.guèri,.guères,.guèt,.guèrem,.guèretz,.guèron|03:erai,eràs,erà,erem,eretz,eràn|04:|05:|06:.ch,.cha|07:,.gam,ètz,.gas,.gam,.gatz|08:.ga,.gas,.ga,.gam,.gatz,.gan|09:.guèsse,.guèsses,.guèsse,.guèssem,.guèssetz,.guèsson|10:eriái,eriás,eriá,eriam,eriatz,erián|', 0, NULL, NULL, 0),
('383', 'ónher', 'conjugason 3, dos rad. -onh- , -ong-, part. pass. Irreg.', '00:|01:|02:.guèri,.guères,.guèt,.guèrem,.guèretz,.guèron|03:erai,eràs,erà,erem,eretz,eràn|04:|05:|06:.chut,.chuda|07:,.gam,ètz,.gas,.gam,.gatz|08:.ga,.gas,.ga,.gam,.gatz,.gan|09:.guèsse,.guèsses,.guèsse,.guèssem,.guèssetz,.guèsson|10:eriái,eriás,eriá,eriam,eriatz,erián|', 0, NULL, NULL, 0),
('384', 'jónher', 'conjugason 3, dos rad. -onh- , -ong-, part. pass. Irreg.', '00:|01:|02:.guèri,.guères,.guèt,.guèrem,.guèretz,.guèron|03:erai,eràs,erà,erem,eretz,eràn|04:|05:|06:.t,.ta|07:,.gam,ètz,.gas,.gam,.gatz|08:.ga,.gas,.ga,.gam,.gatz,.gan|09:.guèsse,.guèsses,.guèsse,.guèssem,.guèssetz,.guèsson|10:eriái,eriás,eriá,eriam,eriatz,erián|', 0, NULL, NULL, 0),
('385', 'frànher', 'conjugason 3, dos rad. -nh- , -ng-, , part. pass. Irreg.', '00:|01:|02:.guèri,.guères,.guèt,.guèrem,.guèretz,.guèron|03:erai,eràs,erà,erem,eretz,eràn|04:|05:|06:.gut,.guda|07:,.gam,ètz,.gas,.gam,.gatz|08:.ga,.gas,.ga,.gam,.gatz,.gan|09:.guèsse,.guèsses,.guèsse,.guèssem,.guèssetz,.guèsson|10:eriái,eriás,eriá,eriam,eriatz,erián|', 0, NULL, NULL, 0),
('390', 'valer', 'conjugason 3, dos rad. -l-, -lg-', '00:|01:|02:guèri,guères,guèt,guèrem,guèretz,guèron|03:|04:|05:|06:gut,guda|07:,gam,ètz,gas,gam,gatz|08:ga,gas,ga,gam,gatz,gan|09:guèsse,guèsses,guèsse,guèssem,guèssetz,guèsson|10:|', 0, NULL, NULL, 0),
('391', 'mòlre', 'conjugason 3, dos rad. -l-, alt. ò / o ', '00:|01:|02:guèri,guères,guèt,guèrem,guèretz,guèron|03:|04:|05:|06:gut,guda|07:,gam,ètz,gas,gam,gatz|08:ga,gas,ga,gam,gatz,gan|09:guèsse,guèsses,guèsse,guèssem,guèssetz,guèsson|10:|', 0, NULL, NULL, 0),
('392', 'voler', 'conjugason 3, dos rad. -l- dos rad. -l-, -lg-, , inf. en -er', '00:..òli,..òles,..òl,èm,ètz,..òlon|01:|02:guèri,guères,guèt,guèrem,guèretz,guèron|03:|04:|05:|06:gut,guda|07:..òlga,gam,gatz,..òlgas,gam,gatz|08:..òlga,..òlgas,..òlga,gam,gatz,..òlgan|09:guèsse,guèsses,guèsse,guèssem,guèssetz,guèsson|10:|', 0, '1', NULL, 0),
('393', 'bólher', 'conjugason 3, dos rad. bolh-, bolhig- (cf. Conj. 2)', '00:|01:|02:iguèri,iguères,iguèt,iguèrem,iguèretz,iguèron|03:irai,iràs,irà,irem,iretz,iràn|04:|05:|06:it,ida|07:,am,ètz,as,am,atz|08:a,as,a,am,atz,an|09:iguèsse,iguèsses,iguèsse,iguèssem,iguèssetz,iguèsson|10:iriái,iriás,iriá,iriam,iriatz,irián|', 0, NULL, NULL, 0),
('394', 'cuèlher', 'conjugason 3, dos rad. colh-, colhig-(cf. conj. 2), alt ò /o (o ', '00:i,es,,....lhèm,....lhètz,on|01:....lhiái,....lhiás,....lhiá,....lhiam,....lhiatz,....lhián|02:....lhiguèri,....lhiguères,....lhiguèt,....lhiguèrem,....lhiguèretz,....lhiguèron|03:....lhirai,....lhiràs,....lhirà,....lhirem,....lhiretz,....lhiràn|04:|05:....lhent|06:....lhit,....lhida|07:,....lham,....lhètz,as,....lham,....lhatz|08:a,as,a,....lham,....lhatz,an|09:....lhiguèsse,....lhiguèsses,....lhiguèsse,....lhiguèssem,....lhiguèssetz,....lhiguèsson|10:....lhiriái,....lhiriás,....lhiriá,....lhiriam,....lhiriatz,....lhirián|', 0, NULL, NULL, 0),
('395', 'parer', 'conjugason 3, dos rad. par-, pareg- (cf. Paréisser)', '00:i,es,,èm,ètz,on|01:|02:eguèri,eguères,eguèt,eguèrem,eguèretz,eguèron|03:eisserai,eisseràs,eisserà,eisserem,eisseretz,eisseràn|04:|05:|06:egut,eguda|07:,escam,ètz,escas,escam,escatz|08:esca,escas,esca,escam,escatz,escan|09:eguèsse,eguèsses,eguèsse,eguèssem,eguèssetz,eguèsson|10:eisseriái,eisseriás,eisseriá,eisseriám,eisseriátz,eisserián|', 0, NULL, NULL, 0),
('396', 'quèrre', 'conjugason 3, dos rad. quèr-, quereg-, alt. iè / è', '00:...ièri,...ières,...ièr,èm,ètz,...ièron|01:|02:eguèri,eguères,eguèt,eguèrem,eguèretz,eguèron|03:|04:|05:|06:egut,eguda|07:...ièr,am,ètz,...ièras,am,atz|08:...ièra,...ièras,...ièra,am,atz,...ièran|09:eguèsse,eguèsses,eguèsse,eguèssem,eguèssetz,eguèsson|10:|', 0, NULL, NULL, 0),
('397', 'córrer', 'conjugason 3, dos rad. corr-, correg-', '00:i,es,.,èm,ètz,on|01:|02:eguèri,eguères,eguèt,eguèrem,eguèretz,eguèron|03:erai,eràs,erà,erem,eretz,eràn|04:|05:|06:egut,eguda|07:.,am,ètz,as,am,atz|08:a,as,a,am,atz,an|09:eguèsse,eguèsses,eguèsse,eguèssem,eguèssetz,eguèsson|10:eriái,eriás,eriá,eriam,eriatz,erián|', 0, NULL, NULL, 0),
('117 b', 'estar', '', NULL, 0, NULL, NULL, 0),
('117 a', 'dar', '', NULL, 0, NULL, NULL, 0),
('107 b', 'estar', 'Modèl 107 : conjugason 1 monosillabs', NULL, 0, NULL, NULL, 0),
('200', 'bastir', 'conjugason 2 radical consonantic', NULL, 0, NULL, NULL, 0),
('210', 'traïr', 'conjugason 2 radical vocalic (a) : traïr', NULL, 0, NULL, NULL, 0),
('211', 'obeïr', 'conjugason 2 radical vocalic (e)', NULL, 0, NULL, NULL, 0),
('212', 'padoïr', 'conjugason 2 radical vocalic (o)', NULL, 0, NULL, NULL, 0),
('213', 'polluïr', 'conjugason 2 radical vocalic (u)', NULL, 0, NULL, NULL, 0),
('220', 'cobrir', 'conjugason 2 part passat -èrt', NULL, 0, NULL, NULL, 0),
('250', 'sentir', 'conjugason 2 mièja sufixada', NULL, 0, NULL, NULL, 0),
('311a', 'saupre', 'conjugason 3 tres radicals, alt b/p', '00:i,es,.p,èm,ètz,on|01:|02:.pèri,.pères,.pèt,.pèrem,.pèretz,.pèron|03:.prai,.pràs,.prà,.prem,.pretz,.pràn|04:|05:|06:.put,.puda|07:.pia,.piam,.piatz,.pias,.piam,.piatz|08:.pia,.pias,.pia,.piam,.piatz,.pian|09:.pèsse,.pèsses,.pèsse,.pèssem,.pèssetz,.pèsson|10:.priái,.priás,.priá,.priam,.priatz,.prián|', 0, NULL, NULL, 0),
('373a', 'prendre', 'conjugason 3, dos rad. pren-, preng-, inf. e part. pas. Irr.', '00:.i,.es,.,.èm,.ètz,.on|01:.iái,.iás,.iá,.iam,.iatz,.ián|02:.guèri,.guères,.guèt,.guèrem,.guèretz,.guèron|03:|04:|05:.ent|06:..s,..sa|07:.,.gam,.ètz,.gas,.gam,.gatz|08:.ga,.gas,.ga,.gam,.gatz,.gan|09:.guèsse,.guèsses,.guèsse,.guèssem,.guèssetz,.guèsson|10:|', 0, NULL, NULL, 0),
('316', 'sègre', 'voir seguir', '00:i,es,.c,èm,ètz,on|01:|02:.guèri,.guères,.guèt,.guèrem,.guèretz,.guèron|03:|04:|05:|06:|07:.c,.gam,ètz,.gas,.gam,.gatz|08:.ga,.gas,.ga,.gam,.gatz,.gan|09:.guèsse,.guèsses,.guèsse,.guèssem,.guèssetz,.guèsson|10:|', 0, NULL, NULL, 0),
('116 b', 'pimpeiar', 'tematic, alternància è/e, radical en i inaccentuable', NULL, 0, NULL, NULL, 0);
